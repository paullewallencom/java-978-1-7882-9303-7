package com.eldermoraes.ch05.programmatic;

/**
 *
 * @author eldermoraes
 */
public class Roles {
    public static final String ADMIN = "admin";
    public static final String USER = "user";
}
    
