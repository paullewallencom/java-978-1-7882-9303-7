package com.eldermoraes.ch01.mvc;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

/**
 *
 * @author eldermoraes
 */
@ApplicationPath("webresources")
public class AppConfig extends Application{

}