function message(){
    alert("Hello Java EE 8");
}