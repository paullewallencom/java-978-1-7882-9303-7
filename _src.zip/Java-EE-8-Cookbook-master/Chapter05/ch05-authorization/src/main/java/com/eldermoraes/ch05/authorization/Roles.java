package com.eldermoraes.ch05.authorization;

/**
 *
 * @author eldermoraes
 */
public class Roles {
    public static final String ROLE1 = "role1";
    public static final String ROLE2 = "role2";
    public static final String ROLE3 = "role3";
}
    
