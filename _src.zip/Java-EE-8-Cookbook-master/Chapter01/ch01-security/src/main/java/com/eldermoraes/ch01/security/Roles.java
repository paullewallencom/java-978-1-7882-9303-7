package com.eldermoraes.ch01.security;

/**
 *
 * @author eldermoraes
 */
public class Roles {
    public static final String ADMIN = "ADMIN";
    public static final String OPERATOR = "OPERATOR";
}
