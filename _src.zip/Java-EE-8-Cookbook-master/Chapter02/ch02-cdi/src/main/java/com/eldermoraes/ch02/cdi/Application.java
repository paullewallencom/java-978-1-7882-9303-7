package com.eldermoraes.ch02.cdi;

import javax.ws.rs.ApplicationPath;

/**
 *
 * @author eldermoraes
 */
@ApplicationPath("webresources")
public class Application extends javax.ws.rs.core.Application {
    
}
