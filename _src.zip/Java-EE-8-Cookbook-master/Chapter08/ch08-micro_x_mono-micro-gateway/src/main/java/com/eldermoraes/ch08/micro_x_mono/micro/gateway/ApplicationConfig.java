package com.eldermoraes.ch08.micro_x_mono.micro.gateway;

import javax.ws.rs.core.Application;

/**
 *
 * @author eldermoraes
 */
@javax.ws.rs.ApplicationPath("webresources")
public class ApplicationConfig extends Application {
    
}
