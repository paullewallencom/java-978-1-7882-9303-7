docker push eldermoraes/gf-javaee-jdk8
