  docker login
  docker push eldermoraes/gf-javaee-cookbook