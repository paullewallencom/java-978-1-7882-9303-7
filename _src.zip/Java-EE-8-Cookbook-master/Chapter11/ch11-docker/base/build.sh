docker build -t eldermoraes/gf-javaee-jdk8 .
