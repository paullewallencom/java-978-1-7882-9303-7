package com.eldermoraes.ch09.proxy.task;

import javax.ws.rs.core.Application;

/**
 *
 * @author eldermoraes
 */
@javax.ws.rs.ApplicationPath("/")
public class ApplicationConfig extends Application {

}
